package com.demo.exception;

@SuppressWarnings("serial")
public class UserException extends RuntimeException{
	
	public UserException() {
		
	}
	
	public UserException(String message) {
		
	}

}
